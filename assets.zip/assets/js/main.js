/*=============== FILTERS TABS ===============*/
const tabs = document.querySelectorAll('[data-target]'),
      tabContents = document.querySelectorAll('[data-content]')

tabs.forEach(tab => {
    tab.addEventListener('click', () => {
        const target = document.querySelector(tab.dataset.target)

        tabContents.forEach(tc => {
            tc.classList.remove('filters__active')
        })
        target.classList.add('filters__active')

        tabs.forEach(t => {
            t.classList.remove('filter-tab-active')
        })
        tab.classList.add('filter-tab-active')
    })
})

/*=============== DARK LIGHT THEME ===============*/
const themeButton = document.getElementById('theme-button')
const darkTheme = 'dark-theme'
const iconTheme = 'ri-sun-line'

// Previously selected topic (if user selected)
const selectedTheme = localStorage.getItem('selected-theme')
const selectedIcon = localStorage.getItem('selected-icon')

// We obtain the current theme that the interface has by validating the dark-theme class
const getCurrentTheme = () => document.body.classList.contains(darkTheme) ? 'dark' : 'light'
const getCurrentIcon = () => themeButton.classList.contains(iconTheme) ? 'ri-moon-line' : 'ri-sun-line'

// We validate if the user previously chose a topic
if (selectedTheme) {
    // If the validation is fulfilled, we ask what the issue was to know if we activated or deactivated the dark
    document.body.classList[selectedTheme === 'dark' ? 'add' : 'remove'](darkTheme)
    themeButton.classList[selectedIcon === 'ri-moon-line' ? 'add' : 'remove'](iconTheme)
} else {
    // If no theme was selected before, set dark theme by default
    document.body.classList.add(darkTheme) // Bật chế độ tối mặc định
    themeButton.classList.add(iconTheme) // Đặt biểu tượng mặt trời
}

// Activate / deactivate the theme manually with the button
themeButton.addEventListener('click', () => {
    // Add or remove the dark / icon theme
    document.body.classList.toggle(darkTheme)
    themeButton.classList.toggle(iconTheme)
    // We save the theme and the current icon that the user chose
    localStorage.setItem('selected-theme', getCurrentTheme())
    localStorage.setItem('selected-icon', getCurrentIcon())

    // Cập nhật particles khi thay đổi theme
    updateParticlesColor();
})

/*=============== PARTICLES CONFIGURATION ===============*/
const updateParticlesColor = () => {
    const theme = getCurrentTheme(); // Lấy theme hiện tại
    const particlesConfig = {
        particles: {
            number: {
                value: 60, // Giảm số lượng hạt
                density: {
                    enable: true,
                    value_area: 800, // Điều chỉnh mật độ để phân bổ đều hơn
                }
            },
            color: {
                value: theme === 'dark' ? "#ffffff" : "#000000" // Đổi màu dựa trên theme
            },
            shape: {
                type: "circle", // Dùng hình tròn đơn giản để giảm tải
            },
            opacity: {
                value: 0.5, // Giảm độ đục để tạo cảm giác mượt mà
                random: true
            },
            size: {
                value: 3, // Kích thước hạt nhỏ hơn
                random: true
            },
            line_linked: {
                enable: true,
                distance: 150, // Giảm khoảng cách liên kết
                color: theme === 'dark' ? "#ffffff" : "#000000",
                opacity: 0.4,
                width: 1
            },
            move: {
                enable: true,
                speed: 2, // Giảm tốc độ di chuyển để đỡ lag
                direction: "none",
                random: false,
                straight: false,
                out_mode: "out",
                bounce: false
            }
        },
        interactivity: {
            detect_on: "canvas",
            events: {
                onhover: {
                    enable: true,
                    mode: "repulse" // Hiệu ứng khi hover
                },
                onclick: {
                    enable: true,
                    mode: "push" // Thêm hạt khi click
                },
                resize: true
            },
            modes: {
                repulse: {
                    distance: 100, // Giảm khoảng cách đẩy
                    duration: 0.4
                },
                push: {
                    particles_nb: 4 // Số hạt thêm khi click
                }
            }
        },
        retina_detect: true
    };

    // Khởi tạo particles.js với cấu hình đã chỉnh sửa
    particlesJS('particles-js', particlesConfig);
};

// Khởi tạo particles ngay khi trang tải
document.addEventListener('DOMContentLoaded', () => {
    updateParticlesColor();
});


/*=============== SCROLL REVEAL ANIMATION ===============*/










