document.getElementById('enterButton').addEventListener('click', function () {
    // Ẩn bảng thông tin
    document.getElementById('infoBox').style.display = 'none';

    // Hiển thị nội dung chính
    document.getElementById('mainContent').style.display = 'block';
});
