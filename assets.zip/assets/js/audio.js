
// Danh sách các bài hát
// Nút và phần tử DOM
const settingsIcon = document.getElementById("settings-icon");
const musicPlayer = document.getElementById("music-player");
const songList = document.getElementById("song-list");
const audioPlayer = document.getElementById("audio-player");
const audioSource = document.getElementById("audio-source");

// Danh sách bài hát
/*
const songs = [
    { title: "🎶 Nơi Vực Nơi Trời", url: "https://files.catbox.moe/bpvnyy.mp3" },
    { title: "🌅 Đom Đóm Remix", url: "https://files.catbox.moe/jgacku.mp3" },
    { title: "🎸 Naruto | Departune to the front lines", url: "https://files.catbox.moe/ahpek3.mp3" },
    { title: "🎸 Không Lấy Được Vợ Remix", url: "https://files.catbox.moe/gueh1j.mp3" }
];

// Tải danh sách bài hát vào giao diện
function loadSongs() {
    songs.forEach((song, index) => {
        const listItem = document.createElement("li");
        listItem.textContent = song.title;
        listItem.addEventListener("click", () => {
            playSong(index);
        });
        songList.appendChild(listItem);
    });
}

// Phát bài hát
function playSong(index) {
    const song = songs[index];
    audioSource.src = song.url;
    audioPlayer.load();
    audioPlayer.play();
}

// Hiển thị hoặc ẩn trình phát nhạc
settingsIcon.addEventListener("click", () => {
    if (musicPlayer.classList.contains("hidden")) {
        musicPlayer.classList.remove("hidden");
        musicPlayer.classList.add("visible");
    } else {
        musicPlayer.classList.remove("visible");
        musicPlayer.classList.add("hidden");
    }
});

// Tải danh sách bài hát khi trang được tải
document.addEventListener("DOMContentLoaded", loadSongs);

*/
